package com.service.order_service.controller;

import com.service.order_service.entity.Cart;
import com.service.order_service.entity.CartItem;
import com.service.order_service.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/carts")
public class cartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/create")
    public Cart createCart(@RequestParam Long userId) {
        return cartService.createCart(userId);
    }

    @PostMapping("/{cartId}/addItem")
    public CartItem addItemToCart(@PathVariable Long cartId, @RequestParam Long carId, @RequestParam String addons, @RequestParam Long washPackageId) {
        return cartService.addItemToCart(cartId, carId, addons, washPackageId);
    }

    @GetMapping("/{cartId}/items")
    public List<CartItem> getCartItems(@PathVariable Long cartId) {
        return cartService.getCartItems(cartId);
    }
}
