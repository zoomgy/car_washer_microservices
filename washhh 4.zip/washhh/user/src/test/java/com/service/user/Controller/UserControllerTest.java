package com.service.user.Controller;

import com.service.user.Model.*;
import com.service.user.Service.CartService;
import com.service.user.Service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserControllerTest {

    @Mock
    private UserService userService;

    @Mock
    private CartService cartService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAdminById() {
        Long userId = 1L;
        User user = new User();
        user.setId(userId);
        when(userService.getUserById(userId)).thenReturn(Optional.of(user));

        Optional<User> result = userController.getAdminById(userId);

        assertTrue(result.isPresent());
        assertEquals(userId, result.get().getId());
    }

    @Test
    public void testGetAllUsers() {
        List<User> users = List.of(new User(), new User());
        when(userService.getAllUsers()).thenReturn(users);

        ResponseEntity<List<User>> response = userController.getAllUsers();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    public void testRegisterUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setEmail("test@example.com");
        user.setPassword("password");

        when(userService.registerUser(user)).thenReturn("User registered successfully!");

        ResponseEntity<String> response = userController.registerUser(user);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("User registered successfully!", response.getBody());
    }

    @Test
    public void testLoginUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("password");

        when(userService.login(user.getUsername(), user.getPassword())).thenReturn("token");

        ResponseEntity<String> response = userController.loginUser(user);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("token", response.getBody());
    }

    @Test
    public void testAddCarToUser() {
        Long userId = 1L;
        Car car = new Car();
        car.setUserId(userId);

        when(userService.addNewCar(userId, car)).thenReturn(ResponseEntity.ok(car));

        ResponseEntity<Car> response = userController.addCarToUser(userId, car);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userId, response.getBody().getUserId());
    }

    @Test
    public void testGetCarByUserId() {
        Long userId = 1L;
        List<Car> cars = List.of(new Car(), new Car());

        when(userService.getCarByUserId(userId)).thenReturn(ResponseEntity.ok(cars));

        ResponseEntity<List<Car>> response = userController.getCarByUserId(userId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    public void testGetAllCar() {
        List<Car> cars = List.of(new Car(), new Car());

        when(userService.getAllCar()).thenReturn(ResponseEntity.ok(cars));

        ResponseEntity<List<Car>> response = userController.getAllCar();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    public void testAddWasherToUser() {
        WashPackage washPackage = new WashPackage();

        when(userService.addNewWasher(washPackage)).thenReturn(ResponseEntity.ok(washPackage));

        ResponseEntity<WashPackage> response = userController.addWasherToUser(washPackage);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }

    @Test
    public void testGetAllWasher() {
        List<WashPackage> washPackages = List.of(new WashPackage(), new WashPackage());

        when(userService.getAllWasher()).thenReturn(ResponseEntity.ok(washPackages));

        ResponseEntity<List<WashPackage>> response = userController.getAllWasher();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().size());
    }

    @Test
    public void testPlaceOrder() {
        Long userId = 1L;
        Order order = new Order();
        order.setUserId(userId);
        order.setStatus("PENDING");

        when(userService.placeOrder(userId, order)).thenReturn(order);

        ResponseEntity<Order> response = userController.placeOrder(userId, order);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userId, response.getBody().getUserId());
        assertEquals("PENDING", response.getBody().getStatus());
    }

    @Test
    public void testAcceptOrder() {
        Long washerId = 1L;
        Long orderId = 1L;
        Order order = new Order();

        when(userService.washerAcceptOrder(washerId, orderId)).thenReturn(order);

        ResponseEntity<Order> response = userController.acceptOrder(washerId, orderId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
    }



}
