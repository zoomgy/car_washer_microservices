package com.service.user.Service;

import com.service.user.Model.Car;
import com.service.user.Model.Order;
import com.service.user.Model.User;
import com.service.user.Model.WashPackage;
import com.service.user.Repository.UserRepository;
import com.service.user.Security.JwtUtil;
import com.service.user.client.CarClient;
import com.service.user.client.OrderClient;
import com.service.user.client.WasherClient;
import com.service.user.config.OrderPublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private OrderClient orderClient;

    @Mock
    private CarClient carClient;

    @Mock
    private WasherClient washerClient;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private OrderPublisher orderPublisher;

    @InjectMocks
    private UserService userService;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllUsers() {
        List<User> users = List.of(new User(), new User());
        when(userRepository.findAll()).thenReturn(users);

        List<User> result = userService.getAllUsers();

        assertEquals(2, result.size());
        verify(userRepository, times(1)).findAll();
    }

    @Test
    public void testGetUserById() {
        Long userId = 1L;
        User user = new User();
        user.setId(userId);
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));

        Optional<User> result = userService.getUserById(userId);

        assertTrue(result.isPresent());
        assertEquals(userId, result.get().getId());
    }

    @Test
    public void testRegisterUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setEmail("test@example.com");
        user.setPassword("password");

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.empty());
        when(userRepository.findByEmail("test@example.com")).thenReturn(Optional.empty());
        when(userRepository.save(any(User.class))).thenReturn(user);

        String result = userService.registerUser(user);

        assertEquals("User registered successfully!", result);
        verify(userRepository, times(1)).findByUsername("testuser");
        verify(userRepository, times(1)).findByEmail("test@example.com");
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    public void testLogin() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword(passwordEncoder.encode("password"));
        user.setRole("USER");

        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(user));
        when(jwtUtil.generateToken("testuser", "USER")).thenReturn("token");

        String result = userService.login("testuser", "password");

        System.out.println("Encoded password: " + user.getPassword());
        System.out.println("Result: " + result);

        assertEquals("token", result);
    }

    @Test
    public void testAddNewCar() {
        Long userId = 1L;
        Car car = new Car();
        car.setUserId(userId);

        when(carClient.addNewCar(any(Car.class))).thenReturn(ResponseEntity.ok(car));

        ResponseEntity<Car> result = userService.addNewCar(userId, car);

        assertEquals(userId, result.getBody().getUserId());
    }

    @Test
    public void testGetCarByUserId() {
        Long userId = 1L;
        List<Car> cars = List.of(new Car(), new Car());

        when(carClient.getCarsByUserID(userId)).thenReturn(ResponseEntity.ok(cars));

        ResponseEntity<List<Car>> result = userService.getCarByUserId(userId);

        assertEquals(2, result.getBody().size());
    }

    @Test
    public void testGetAllCar() {
        List<Car> cars = List.of(new Car(), new Car());

        when(carClient.getAllCar()).thenReturn(ResponseEntity.ok(cars));

        ResponseEntity<List<Car>> result = userService.getAllCar();

        assertEquals(2, result.getBody().size());
    }

    @Test
    public void testAddNewWasher() {
        WashPackage washPackage = new WashPackage();

        when(washerClient.addWashPackage(any(WashPackage.class))).thenReturn(washPackage);

        ResponseEntity<WashPackage> result = userService.addNewWasher(washPackage);

        assertNotNull(result.getBody());
    }

    @Test
    public void testGetAllWasher() {
        List<WashPackage> washPackages = List.of(new WashPackage(), new WashPackage());

        when(washerClient.getAllWashPackage()).thenReturn(washPackages);

        ResponseEntity<List<WashPackage>> result = userService.getAllWasher();

        assertEquals(2, result.getBody().size());
    }

    @Test
    public void testWasherAcceptOrder() {
        Long washerId = 1L;
        Long orderId = 1L;
        Order order = new Order();

        when(orderClient.acceptOrder(orderId, washerId)).thenReturn(order);

        Order result = userService.washerAcceptOrder(washerId, orderId);

        assertNotNull(result);
    }

    @Test
    public void testPlaceOrder() {
        Long userId = 1L;
        Order order = new Order();
        order.setUserId(userId);
        order.setStatus("PENDING");
        order.setOrderDate(LocalDateTime.now());

        when(orderClient.createOrder(any(Order.class))).thenReturn(order);

        Order result = userService.placeOrder(userId, order);

        assertEquals(userId, result.getUserId());
        assertEquals("PENDING", result.getStatus());
    }
}
