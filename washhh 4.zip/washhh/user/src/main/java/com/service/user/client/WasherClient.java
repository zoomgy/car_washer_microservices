package com.service.user.client;
import com.service.user.Model.WashPackage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;

@FeignClient(name = "washerClient", url = "http://localhost:8083/")
public interface WasherClient {
    @PostMapping("/washPackage/add")
    public WashPackage addWashPackage(@RequestBody WashPackage washPackage);

    @GetMapping("/washPackage/all")
    public List<WashPackage> getAllWashPackage();
}