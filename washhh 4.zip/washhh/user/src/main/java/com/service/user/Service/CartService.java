package com.service.user.Service;

import com.service.user.Model.Cart;
import com.service.user.Model.CartItem;
import com.service.user.client.CartClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service

public class CartService {
    @Autowired
    CartClient cartClient;
    public Cart createCart(Long userId) {
        return cartClient.createCart(userId);

    }

    public CartItem addItemToCart(Long cartId, Long carId, String addons, Long washPackageId) {
            return cartClient.addItemToCart(cartId,carId,addons,washPackageId);
    }

    public List<CartItem> getCartItems(Long cartId) {
        return cartClient.getCartItems(cartId);
    }
}
