package com.service.admin.Controller;

import com.service.admin.Model.Car;
import com.service.admin.Service.CarService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/car")
public class CarController {

    private final CarService service;

    public CarController(CarService service) {
        this.service = service;
    }

    // Endpoint to add a new car
    @PostMapping("/addCar")
    public ResponseEntity<Car> addNewCar(@RequestBody Car car) {
        Car savedCar = service.addNewCar(car);
        return new ResponseEntity<>(savedCar, HttpStatus.CREATED);
    }

    @GetMapping("/getCar/{id}")
    public ResponseEntity<Car> getCarById(@PathVariable Long id){
        return new ResponseEntity<>(service.getCarById(id),HttpStatus.OK);
    }

    @GetMapping("/getCarByUserId/{id}")
    public ResponseEntity<List<Car>> getCarsByUserID(@PathVariable Long id){
        return new ResponseEntity<>(service.getCarByUserId(id),HttpStatus.OK);
    }

    // Endpoint to delete a car by ID
    @DeleteMapping("/deleteCar/{id}")
    public ResponseEntity<String> deleteCar(@PathVariable Long id) {
        boolean isDeleted = service.deleteACar(id);
        if (isDeleted) {
            return new ResponseEntity<>("Car successfully deleted.", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Car not found.", HttpStatus.NOT_FOUND);
        }
    }

    // Additional endpoints could be added here as needed for other functionalities.
}