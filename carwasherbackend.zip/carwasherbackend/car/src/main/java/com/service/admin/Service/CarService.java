package com.service.admin.Service;


import com.service.admin.Model.Car;
import com.service.admin.Repository.CarRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarService {

    @Autowired
    public CarRepository carRepository;

    public Car addNewCar(Car car){
        return carRepository.save(car);
    }

    public Car getCarById(Long id){
        Optional<Car> car = carRepository.findById(id);
        return car.orElse(null);
    }

    public List<Car> getCarByUserId(Long userId){
        return carRepository.findAll().stream().filter(car -> car.getUserId().equals(userId)).toList();
    }

    public boolean deleteACar(Long id) {
        try {
            Car carForDelete = carRepository.findById(id).get();
            carRepository.delete(carForDelete); // Deletes the retrieved car entry
            return true; // Successfully deleted
        } catch (EntityNotFoundException e) {
            return false; // Handle the case where the car with the given ID doesn't exist
        }
    }
}
