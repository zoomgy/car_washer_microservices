package com.service.user.Controller;

import com.service.user.Model.Car;
import com.service.user.Model.User;
import com.service.user.Model.Washer;
import com.service.user.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService service;

    @Autowired
    public UserController(UserService service) {
        this.service = service;
    }

    @GetMapping("/{id}")
    public Optional<User> getAdminById(@PathVariable Long id) {
        return service.getUserById(id);
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = service.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        String result = service.registerUser(user);
        if (result.equals("User registered successfully!")) {
            return ResponseEntity.status(HttpStatus.CREATED).body(result);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody User user) {
        String result = service.login(user.getUsername(), user.getPassword());

        if (result.equals("User not found!") || result.equals("Invalid credentials!")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(result);
        } else {
            return ResponseEntity.ok(result);
        }
    }

    @PostMapping("/addcar/{id}")
    public ResponseEntity<Car> addCarToUser(@PathVariable Long id, @RequestBody Car car) {
        return service.addNewCar(id, car);
    }

    @GetMapping("/getCarByUserId/{id}")
    public ResponseEntity<List<Car>> getCarByUserId(@PathVariable Long id) {
        return service.getCarByUserId(id);
    }

    // 🚀 Add washer
    @PostMapping("/addwasher/{id}")
    public ResponseEntity<Washer> addWasherToUser(@PathVariable Long id, @RequestBody Washer washer) {
        return service.addNewWasher(id, washer);
    }

    // 🚀 Get all washers of user
    @GetMapping("/getWasherByUserId/{id}")
    public ResponseEntity<List<Washer>> getWasherByUserId(@PathVariable Long id) {
        return service.getWasherByUserId(id);
    }

    @GetMapping("/getAllWasher")
    public ResponseEntity<List<Washer>> getAllWasher(){
        return service.getAllWasher();
    }
}
