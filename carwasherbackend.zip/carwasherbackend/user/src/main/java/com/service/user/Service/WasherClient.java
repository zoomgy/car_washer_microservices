package com.service.user.Service;
import com.service.user.Model.Car;
import com.service.user.Model.Washer;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;

@FeignClient(name = "washerClient", url = "http://localhost:8083/")public interface WasherClient {
    @PostMapping("/washer/add")
    public Washer addWasher(@RequestBody Washer washer);
    @GetMapping("/washer/user/{userId}")
    public List<Washer> getWasherByUserId(@PathVariable Long userId);
    @GetMapping("/washer/all")
    public List<Washer> getAllWasher();
}