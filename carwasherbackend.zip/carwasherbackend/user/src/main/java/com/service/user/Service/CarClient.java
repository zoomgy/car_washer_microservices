package com.service.user.Service;

import com.service.user.Model.Car;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient(name = "exampleClient", url = "http://localhost:8081/")
public interface CarClient {

    @GetMapping("/car/getAllCar")
    public ResponseEntity<List<Car>> getAllCar();

    @PostMapping("/car/addCar")
    public ResponseEntity<Car> addNewCar(@RequestBody Car car);

    @GetMapping("/car/getCarByUserId/{id}")
    public ResponseEntity<List<Car>> getCarsByUserID(@PathVariable Long id);
}