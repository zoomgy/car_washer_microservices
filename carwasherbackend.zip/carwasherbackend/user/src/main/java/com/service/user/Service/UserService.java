package com.service.user.Service;

import com.service.user.Model.Car;
import com.service.user.Model.User;
import com.service.user.Model.Washer;
import com.service.user.Repository.UserRepository;
import com.service.user.Security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository repository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Autowired
    private CarClient carClient;

    @Autowired
    private WasherClient washerClient;

    @Autowired
    JwtUtil jwtUtil;

    @Autowired
    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public List<User> getAllUsers() {
        return repository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return repository.findById(id);
    }

    public String registerUser(User user) {
        Optional<User> existingUser = repository.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            return "Username already exists!";
        }
        Optional<User> existingEmail = repository.findByEmail(user.getEmail());
        if (existingEmail.isPresent()) {
            return "Email already exists!";
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        repository.save(user);

        return "User registered successfully!";
    }

    public String login(String username, String password) {
        Optional<User> existingUser = repository.findByUsername(username);

        if (!existingUser.isPresent()) {
            return "User not found!";
        }

        User user = existingUser.get();
        if (!passwordEncoder.matches(password, user.getPassword())) {
            return "Invalid credentials!";
        }

        return jwtUtil.generateToken(user.getUsername(), user.getRole());
    }

    public ResponseEntity<Car> addNewCar(Long id, Car car) {
        car.setUserId(id);
        return carClient.addNewCar(car);
    }

    public ResponseEntity<List<Car>> getCarByUserId(Long id) {
        return carClient.getCarsByUserID(id);
    }

    // 🚀 Add a new washer for the user
    public ResponseEntity<Washer> addNewWasher(Long userId, Washer washer) {
        washer.setUserId(userId);
        Washer createdWasher = washerClient.addWasher(washer);
        return ResponseEntity.ok(createdWasher);
    }

    public ResponseEntity<List<Washer>> getWasherByUserId(Long id) {
        List<Washer> washers = washerClient.getWasherByUserId(id);
        return ResponseEntity.ok(washers);
    }

    public ResponseEntity<List<Washer>> getAllWasher(){
        return ResponseEntity.ok(washerClient.getAllWasher());
    }
}
