package com.service.admin.config;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class WasherOrderListener {

    @RabbitListener(queues = RabbitMQConfig.QUEUE)
    public void receiveNewOrder(Order order) {
        System.out.println("📢 New order received for washer notification: " + order.getId());
        // Optionally notify washer via email, SMS, WebSocket, etc.
    }
}
