package com.service.admin.Controller;

import com.service.admin.Model.Washer;
import com.service.admin.Service.WasherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/washer")
public class WasherController {

    private final WasherService service;

    @Autowired
    public WasherController(WasherService service) {
        this.service = service;
    }

    @PostMapping("/add")
    public Washer addWasher(@RequestBody Washer washer) {
        return service.addWasher(washer);
    }

    @GetMapping("/all")
    public List<Washer> getAllWashers() {
        return service.getAllWashers();
    }

    @GetMapping("/{id}")
    public Washer getWasherById(@PathVariable Long id) {
        return service.getWasherById(id);
    }

    @GetMapping("/user/{userId}")
    public List<Washer> getWasherByUserId(@PathVariable Long userId) {
        return service.getWasherByUserId(userId);
    }

}
