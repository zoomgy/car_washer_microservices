package com.service.admin.Service;

import com.service.admin.Model.Washer;
import com.service.admin.Repository.WasherRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WasherService {

    private final WasherRepository washerRepository;

    @Autowired
    public WasherService(WasherRepository washerRepository) {
        this.washerRepository = washerRepository;
    }

    public Washer addWasher(Washer washer) {
        if(!washerRepository.findByUserId(washer.getUserId()).isEmpty()){
            return new Washer(404l,0l,"0","Washer Not Created","Washer with the User Id Already Exists");
        }
        return washerRepository.save(washer);
    }

    public Washer updateWasherDetails(Washer washer) {
        Optional<Washer> optionalWasher = washerRepository.findByUserId(washer.getUserId()).stream().findFirst();
        if (optionalWasher.isEmpty()) {
            return new Washer(404l,0l,"0","Washer Details Not Found","Washer with the User Id Does Not Exists");        }
        Washer washerToUpdate = optionalWasher.get();
        if (washer.getWasherPackage() != null && !washer.getWasherPackage().isBlank()) {
            washerToUpdate.setWasherPackage(washer.getWasherPackage());
        }
        if (washer.getWasherPrice() != null && !washer.getWasherPrice().isBlank()) {
            washerToUpdate.setWasherPrice(washer.getWasherPrice());
        }
        if (washer.getLocation() != null && !washer.getLocation().isBlank()) {
            washerToUpdate.setLocation(washer.getLocation());
        }
        return washerRepository.save(washerToUpdate);
    }

    public List<Washer> getAllWashers() {
        return washerRepository.findAll();
    }

    public Washer getWasherById(Long id) {
        return washerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Washer not found with id: " + id));
    }

    public List<Washer> getWasherByUserId(Long userId) {
        return washerRepository.findByUserId(userId);
    }
}
