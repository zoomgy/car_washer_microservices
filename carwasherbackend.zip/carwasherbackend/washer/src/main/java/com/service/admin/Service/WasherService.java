package com.service.admin.Service;

import com.service.admin.Model.Washer;
import com.service.admin.Repository.WasherRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WasherService {

    private final WasherRepository washerRepository;

    @Autowired
    public WasherService(WasherRepository washerRepository) {
        this.washerRepository = washerRepository;
    }

    public Washer addWasher(Washer washer) {
        return washerRepository.save(washer);
    }

    public List<Washer> getAllWashers() {
        return washerRepository.findAll();
    }

    public Washer getWasherById(Long id) {
        return washerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Washer not found with id: " + id));
    }

    public List<Washer> getWasherByUserId(Long userId) {
        return washerRepository.findByUserId(userId);
    }
}
