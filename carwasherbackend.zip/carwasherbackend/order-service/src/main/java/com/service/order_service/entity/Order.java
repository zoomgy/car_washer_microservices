package com.service.order_service.entity;

import com.service.order_service.model.Car;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long washerId;
    private Long carId;
    private String washPackage;
    private String status; // PENDING, WASHING, COMPLETED, CANCELLED

    private LocalDateTime orderDate;

    public Order() {
        this.orderDate = LocalDateTime.now(); // set current date and time
        this.status = "PENDING";              // default status
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getWasherId() {
        return washerId;
    }

    public void setWasherId(Long washerId) {
        this.washerId = washerId;
    }

    public Long getCarId() {
        return carId;
    }

    public void setCarId(Long carId) {
        this.carId = carId;
    }

    public String getWashPackage() {
        return washPackage;
    }

    public void setWashPackage(String washPackage) {
        this.washPackage = washPackage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }
//
    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    // Getters and Setters
}
