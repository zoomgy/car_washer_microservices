package com.service.admin.Controller;

import com.service.admin.Model.WashPackage;
import com.service.admin.Service.WasherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("washPackage")
public class WasherController {

    private final WasherService service;

    @Autowired
    public WasherController(WasherService service) {
        this.service = service;
    }

    @PostMapping("/add")
    public WashPackage addWashPackage(@RequestBody WashPackage washPackage) {
        return service.addWashPackage(washPackage);
    }

    @GetMapping("/all")
    public List<WashPackage> getAllWashPackage() {
        return service.getAllWashPackage();
    }

    @GetMapping("/{id}")
    public WashPackage getWashPackageById(@PathVariable Long id) {
        return service.getWashPackageById(id);
    }

//    @GetMapping("/user/{userId}")
//    public Optional<WashPackage> getWashPackageByUserId(@PathVariable Long userId) {
//        return Optional.ofNullable(service.getWashPackageById(userId));
//    }

}
