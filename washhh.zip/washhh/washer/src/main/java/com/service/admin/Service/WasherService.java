package com.service.admin.Service;

import com.service.admin.Model.WashPackage;
import com.service.admin.Repository.WasherRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WasherService {

    private final WasherRepository washerRepository;

    @Autowired
    public WasherService(WasherRepository washerRepository) {
        this.washerRepository = washerRepository;
    }

    public WashPackage addWashPackage(WashPackage washPackage) {

        return washerRepository.save(washPackage);
    }

    public WashPackage updateWashPackageDetails(WashPackage washPackage) {

        return washPackage;
    }

    public List<WashPackage> getAllWashPackage() {
        return washerRepository.findAll();
    }

    public WashPackage getWashPackageById(Long id) {
        return washerRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Washer not found with id: " + id));
    }

//    public Optional<WashPackage> getWashPackageByUserId(Long userId) {
//        return washerRepository.findById(userId);
//    }
}
