package com.service.admin.config;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long washerId;
    private Long CartId;

    private String status; // PENDING, WASHING, COMPLETED, CANCELLED

    private LocalDateTime orderDate;
    private LocalDateTime scheduledDate;
    private boolean orderNow;
    String paymentUrl;
    Long paymentId;


    public Order() {
        this.orderDate = LocalDateTime.now(); // set current date and time
        this.status = "PENDING";              // default status
        this.orderNow = true;                 // default to order now
    }
}
