package com.service.order_service;


import com.service.order_service.entity.Cart;
import com.service.order_service.entity.CartItem;
import com.service.order_service.repository.CartRepository;
import com.service.order_service.repository.CartItemRepository;
import com.service.order_service.service.CartService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CartServiceTest {

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CartItemRepository cartItemRepository;

    @InjectMocks
    private CartService cartService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateCart() {
        Long userId = 1L;
        Cart cart = new Cart();
        cart.setUserId(userId);

        when(cartRepository.save(any(Cart.class))).thenReturn(cart);

        Cart createdCart = cartService.createCart(userId);

        assertNotNull(createdCart);
        assertEquals(userId, createdCart.getUserId());
    }

    @Test
    public void testAddItemToCart() {
        Long cartId = 1L;
        Long carId = 1L;
        String addon = "vaccumwash";
        Long washPackageId = 1L;

        Cart cart = new Cart();
        cart.setId(cartId);

        CartItem cartItem = new CartItem();
        cartItem.setCart(cart);
        cartItem.setCarId(carId);
        cartItem.setAddon(addon);
        cartItem.setWashPackageId(washPackageId);

        when(cartRepository.findById(cartId)).thenReturn(Optional.of(cart));
        when(cartItemRepository.save(any(CartItem.class))).thenReturn(cartItem);

        CartItem addedItem = cartService.addItemToCart(cartId, carId, addon, washPackageId);

        assertNotNull(addedItem);
        assertEquals(cartId, addedItem.getCart().getId());
        assertEquals(carId, addedItem.getCarId());
        assertEquals(addon, addedItem.getAddon());
        assertEquals(washPackageId, addedItem.getWashPackageId());

    }

    @Test
    public void testGetCartItems() {
        Long cartId = 1L;
        Cart cart = new Cart();
        cart.setId(cartId);

        CartItem item1 = new CartItem();
        item1.setId(1L);
        item1.setCart(cart);

        CartItem item2 = new CartItem();
        item2.setId(2L);
        item2.setCart(cart);

        cart.setItems(List.of(item1, item2));

        when(cartRepository.findById(cartId)).thenReturn(Optional.of(cart));

        List<CartItem> items = cartService.getCartItems(cartId);

        assertNotNull(items);
        assertEquals(2, items.size());
    }
}

