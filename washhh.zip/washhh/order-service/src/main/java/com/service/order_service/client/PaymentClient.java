package com.service.order_service.client;


import com.service.order_service.model.Payment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@FeignClient(name = "PaymentClient" ,url = "http://localhost:8085/payment")
public interface PaymentClient {
    @PostMapping("/new/{orderId}/{amount}")
    public String createNewPayment(@PathVariable Long orderId, @PathVariable Long amount);

    @GetMapping("/status/{paymentId}")
    public String getPaymentStatus(@PathVariable Long paymentId);

    @GetMapping("/get-all-payment/{orderId}")
    public List<Payment> getAllPayment(@PathVariable Long orderId);
}
