package com.service.order_service.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long washerId;
    private Long CartId;

    private String status; // PENDING, WASHING, COMPLETED, CANCELLED

    private LocalDateTime orderDate;
    private LocalDateTime scheduledDate;
    private boolean orderNow;



    public Order() {
        this.orderDate = LocalDateTime.now(); // set current date and time
        this.status = "PENDING";              // default status
        this.orderNow = true;                 // default to order now
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getWasherId() {
        return washerId;
    }

    public void setWasherId(Long washerId) {
        this.washerId = washerId;
    }



    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    public LocalDateTime getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(LocalDateTime scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public boolean isOrderNow() {
        return orderNow;
    }

    public void setOrderNow(boolean orderNow) {
        this.orderNow = orderNow;
    }

    public Long getCartId() {
        return  CartId;
    }
    public void setCartId(Long cartId){
        this.CartId=cartId;
    }
}
