package com.service.order_service.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "orders")
@Data
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long washerId;
    private Long CartId;

    private String status; // PENDING, WASHING, COMPLETED, CANCELLED

    private LocalDateTime orderDate;
    private LocalDateTime scheduledDate;
    private boolean orderNow;
    @Column(length = 1000)
    private String paymentUrl;
    private Long paymentId;


    public Order() {
        this.orderDate = LocalDateTime.now(); // set current date and time
        this.status = "PENDING";              // default status
        this.orderNow = true;                 // default to order now
    }
}
