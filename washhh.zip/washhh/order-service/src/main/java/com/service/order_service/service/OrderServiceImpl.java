package com.service.order_service.service;

import com.service.order_service.entity.Order;
import com.service.order_service.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Order createOrder(Order order) {
        return orderRepository.save(order);
    }

    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order updateOrder(Long id, Order orderDetails) {
        Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        order.setUserId(orderDetails.getUserId());
        order.setWasherId(orderDetails.getWasherId());
        order.setCartId(orderDetails.getCartId());
        order.setStatus(orderDetails.getStatus());
        order.setOrderDate(orderDetails.getOrderDate());
        order.setScheduledDate(orderDetails.getScheduledDate());
        order.setOrderNow(orderDetails.isOrderNow());
        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        orderRepository.delete(order);
    }



    public Order acceptOrder(Long orderId, Long washerId) {
             Order order = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
             order.setWasherId(washerId);
             order.setStatus("WASHING");
             return orderRepository.save(order);
 }

    @Override
    public Order completeOrder(Long orderId, Long washerId) {
        Order orderToBeCompleted = orderRepository.findById(orderId).orElseThrow(()->new RuntimeException("Order not found"));
        if(!Objects.equals(orderToBeCompleted.getWasherId(), washerId)){
            throw new RuntimeException("Washer can only complete its own order");
        }
        if(orderToBeCompleted.getStatus().equals("COMPLETED")){
            throw new RuntimeException("Order is already completed");
        }
        if(!orderToBeCompleted.getStatus().equals("WASHING")){
            throw new RuntimeException("Washer can only complete an ongoing order.");
        }
        orderToBeCompleted.setStatus("COMPLETED");
        orderRepository.save(orderToBeCompleted);
        return orderToBeCompleted;
    }

}
