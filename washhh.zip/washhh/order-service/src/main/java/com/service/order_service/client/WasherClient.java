package com.service.order_service.client;

import com.service.order_service.model.WashPackage;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;

@FeignClient(name = "washerClient", url = "http://localhost:8083/")
public interface WasherClient {
    @GetMapping("/all")
    public List<WashPackage> getAllWashPackage();

    @GetMapping("/get/{id}")
    public WashPackage getWashPackageById(@PathVariable Long id);
}