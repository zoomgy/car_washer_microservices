package com.service.order_service.service;

import com.service.order_service.entity.Order;

import java.util.List;
import java.util.Optional;

public interface OrderService {

    Order createOrder(Order order);

    Optional<Order> getOrderById(Long id);

    List<Order> getAllOrders();

    Order updateOrder(Long id, Order orderDetails);

    void deleteOrder(Long id);
    Order acceptOrder(Long orderId,Long washerId);
    String completeOrder(Long orderId,Long washerId);
    List<Order> getOrdersByUserId(Long userId);
    List<Order> getPendingOrders();
}
