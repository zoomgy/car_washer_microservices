package com.service.order_service.service;

import com.service.order_service.client.PaymentClient;
import com.service.order_service.client.WasherClient;
import com.service.order_service.entity.Cart;
import com.service.order_service.entity.CartItem;
import com.service.order_service.entity.Order;
import com.service.order_service.model.Payment;
import com.service.order_service.model.WashPackage;
import com.service.order_service.repository.CartRepository;
import com.service.order_service.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class OrderService{

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    CartRepository cartRepository;

    @Autowired
    WasherClient washerClient;

    @Autowired
    private PaymentClient paymentClient;

    public Order createOrder(Order order) {
        return orderRepository.save(order);
    }

    public String createFreshPaymentForOrder(Long orderId){
        Order order = orderRepository.findById(orderId).orElse(null);
        if(order==null)return "Invalid Order Id";
        if(order.getPaymentId()!=null){
            String paymentStatus = getPaymentStatus(order.getPaymentId());
            if(paymentStatus.equals("PENDING")){
                return "PAYMENT IS STILL PENDING PLEASE COMPLETE PAYMENT USING THE PAYMENT URL";
            }else if(paymentStatus.equals("SUCCESS")){
                return "PAYMENT ALREADY COMPLETED";
            }
        }
        Long amount = getOrderAmountFromCartRepo(order);
        String paymentString = createNewPayment(order.getId(),amount);
        if(paymentString.contains("PAYMENT CREATED SUCCESSFULLY WITH PAYMENT URL")){
            String[] paymentParts = paymentString.split(",");
            String paymentStatus = paymentParts[1];
            order.setPaymentId(Long.parseLong(paymentParts[0]));
            order.setPaymentUrl(paymentStatus.substring("PAYMENT CREATED SUCCESSFULLY WITH PAYMENT URL".length()));
        }
        orderRepository.save(order);
        return paymentString;
    }

    public String getPaymentStatus(Long paymentId){
        return paymentClient.getPaymentStatus(paymentId);
    }

    public String createNewPayment(Long orderId,Long amount){
        return paymentClient.createNewPayment(orderId,amount*100);
    }

    public Long getOrderAmountFromCartRepo(Order order){
        Long cartId = order.getCartId();
        Cart cart = cartRepository.findById(cartId).orElse(null);
        Long amount = 0L;
        for(CartItem cartItem : cart.getItems()){
            Long washPackageId = cartItem.getWashPackageId();
            WashPackage washPackage = washerClient.getWashPackageById(washPackageId);
            amount += Long.parseLong(washPackage.getWasherPrice());
        }
        return amount;
    }

    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order updateOrder(Long id, Order orderDetails) {
        Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        order.setUserId(orderDetails.getUserId());
        order.setWasherId(orderDetails.getWasherId());
        order.setCartId(orderDetails.getCartId());
        order.setStatus(orderDetails.getStatus());
        order.setOrderDate(orderDetails.getOrderDate());
        order.setScheduledDate(orderDetails.getScheduledDate());
        order.setOrderNow(orderDetails.isOrderNow());
        return orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        orderRepository.delete(order);
    }



    public String acceptOrder(Long orderId, Long washerId) {
        Order order = orderRepository.findById(orderId).orElseThrow(() -> new RuntimeException("Order not found"));
        if(order.getStatus().equals("WASHING") || order.getStatus().equals("COMPLETED")){
            return "Washer can only accept pending orders";
        }
        Long paymentId = orderRepository.findById(orderId).get().getPaymentId();
        if(paymentId==null || paymentClient.getPaymentStatus(paymentId).equals("PENDING")){
            return "PAYMENT FOR THE ORDER IS PENDING CANNOT ACCEPT ORDER";
        }
        order.setWasherId(washerId);
        order.setStatus("WASHING");
        orderRepository.save(order);
        return "ORDER ACCEPTED SUCCESSFULLY";
    }


    public String completeOrder(Long orderId, Long washerId) {
        Order orderToBeCompleted = orderRepository.findById(orderId).orElseThrow(()->new RuntimeException("Order not found"));
        if(!Objects.equals(orderToBeCompleted.getWasherId(), washerId)){
            return "Washer can only complete its own order";
        }
        if(orderToBeCompleted.getStatus().equals("COMPLETED")){
            return "Order is already completed";
        }
        if(!orderToBeCompleted.getStatus().equals("WASHING")){
            return "Washer can only complete an ongoing order.";
        }
        orderToBeCompleted.setStatus("COMPLETED");
        orderRepository.save(orderToBeCompleted);
        return "COMPLETED";
    }


    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }


    public List<Order> getPendingOrders(){
        return orderRepository.findAll().stream().filter(order -> order.getStatus().equals("PENDING")).toList();
    }

}
