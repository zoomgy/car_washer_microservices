package com.service.order_service.repository;
import java.util.List;

import com.service.order_service.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CartItemRepository extends JpaRepository<CartItem,Long> {
}
