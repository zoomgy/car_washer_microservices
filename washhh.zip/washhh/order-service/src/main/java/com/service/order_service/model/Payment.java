package com.service.order_service.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;


public class Payment {
    private Long id;
    private Long orderId;
    private String status; // PENDING, SUCCESS, CANCELLED
    private LocalDateTime paymentCreationDate;
    private LocalDateTime paymentCompleteDate;
    private String sessionId;
    private String stripePaymentId;
    private Long amount;

    public Payment(){

    }

    public Long getAmount(){
        return this.amount;
    }

    public void setAmount(Long amount){
        this.amount = amount;
    }

    public String getStripePaymentId(){
        return this.stripePaymentId;
    }

    public void setStripePaymentId(String stripePaymentId){
        this.stripePaymentId = stripePaymentId;
    }


    public LocalDateTime getPaymentCompleteDate(){return this.paymentCompleteDate;}
    public void setPaymentCompleteDate(LocalDateTime date){
        this.paymentCompleteDate=date;
    }

    public void setSessionId(String id){
        this.sessionId = id;
    }
    public String getSessionId(){
        return this.sessionId;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }



    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getPaymentCreationDate() {
        return paymentCreationDate;
    }

    public void setPaymentCreationDate(LocalDateTime paymentCreationDate) {
        this.paymentCreationDate = paymentCreationDate;
    }
}
