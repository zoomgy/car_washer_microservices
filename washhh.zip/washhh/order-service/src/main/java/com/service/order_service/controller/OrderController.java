package com.service.order_service.controller;

import com.service.order_service.entity.Order;
import com.service.order_service.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping()
    public Order createOrder(@RequestBody Order order) {
        return orderService.createOrder(order);
    }

    @GetMapping("/{id}")
    public Optional<Order> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id);
    }

    @GetMapping()
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    @PutMapping("/update/{id}")
    public Order updateOrder(@PathVariable Long id, @RequestBody Order orderDetails) {
        return orderService.updateOrder(id, orderDetails);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);
    }

     @PutMapping("/accept/{orderId}/washer/{washerId}")
     public Order acceptOrder(@PathVariable Long orderId, @PathVariable Long washerId) {
     return orderService.acceptOrder(orderId, washerId);
     }

     @PutMapping("/complete/{orderId}/washer/{washerId}")
     public String completeOrder(@PathVariable Long orderId,@PathVariable Long washerId){
            return orderService.completeOrder(orderId,washerId);
     }

    @GetMapping("/orders/{userId}")
    List<Order> getOrdersByUserId(@PathVariable Long userId){
        return orderService.getOrdersByUserId(userId);
    }

    @GetMapping("/get-pending-orders")
    List<Order> getPendingOrders(){
        return orderService.getPendingOrders();
    }

}
