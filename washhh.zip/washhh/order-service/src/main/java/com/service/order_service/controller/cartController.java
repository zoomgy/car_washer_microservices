package com.service.order_service.controller;

import com.service.order_service.entity.Cart;
import com.service.order_service.entity.CartItem;
import com.service.order_service.model.Car;
import com.service.order_service.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/carts")
public class cartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/create")
    public Cart createCart(@RequestParam Long userId) {
        return cartService.createCart(userId);
    }

    @PostMapping("/{cartId}/addItem")
    public CartItem addItemToCart(@PathVariable Long cartId, @RequestParam Long carId, @RequestParam String addons, @RequestParam Long washPackageId) {
        return cartService.addItemToCart(cartId, carId, addons, washPackageId);
    }

    @GetMapping("/{cartId}/items")
    public List<CartItem> getCartItems(@PathVariable Long cartId) {
        return cartService.getCartItems(cartId);
    }

    @GetMapping("/getCartByUserId/{userId}")
    public List<Cart> getCartByUserId(@PathVariable Long userId){
        return cartService.getCartByUserId(userId);
    }

    @GetMapping("/getCartById/{cartId}")
    public Cart getCartById(@PathVariable Long cartId){
        return cartService.getCartById(cartId).orElse(null);
    }

    @DeleteMapping("/deleteCart/{cartId}")
    public String deleteCart(@PathVariable Long cartId){
        return cartService.deleteCart(cartId);
    }

    @DeleteMapping("/deleteItem/{cartId}/{itemId}")
    public ResponseEntity<String> deleteItem(@PathVariable Long cartId, @PathVariable Long itemId) {

        Cart cart = cartService.getCartById(cartId).get();

        CartItem item = cart.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Invalid item Id"));

        cartService.deleteItem(itemId,cart);

        return ResponseEntity.ok("Item deleted successfully");
    }

}
