package com.service.order_service.service;


import com.service.order_service.entity.Cart;
import com.service.order_service.entity.CartItem;
import com.service.order_service.model.Car;
import com.service.order_service.repository.CartRepository;
import com.service.order_service.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    public Cart createCart(Long userId) {
        Cart cart = new Cart();
        cart.setUserId(userId);
        return cartRepository.save(cart);
    }

    public CartItem addItemToCart(Long cartId, Long carId, String addon, Long washPackageId) {
        Cart cart = cartRepository.findById(cartId).orElseThrow(() -> new RuntimeException("Cart not found"));
        CartItem cartItem = new CartItem();
        cartItem.setCart(cart);
        cartItem.setCarId(carId);
        cartItem.setAddon(addon);
        cartItem.setWashPackageId(washPackageId);
        return cartItemRepository.save(cartItem);
    }

    public List<CartItem> getCartItems(Long cartId) {
        Cart cart = cartRepository.findById(cartId).orElseThrow(() -> new RuntimeException("Cart not found"));
        return cart.getItems();
    }

    public List<Cart> getCartByUserId(Long userId){
        return cartRepository.findAll().stream().filter(cart -> cart.getUserId().equals(userId)).toList();
    }

    public Optional<Cart> getCartById(Long cartId){
        return cartRepository.findById(cartId);
    }

    public String deleteCart(Long cartId){
        Optional<Cart> cartToBeDeleted = cartRepository.findById(cartId);
        cartRepository.deleteById(cartId);
        return "Cart Deleted Successfully";
    }

    public void deleteItem(Long itemId, Cart cart) {
        CartItem item = cart.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Item not found with id: " + itemId));

        // Remove the item from the cart's list
        cart.getItems().remove(item);
    }
}
