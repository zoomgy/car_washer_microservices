package com.service.order_service.service;


import com.service.order_service.entity.Cart;
import com.service.order_service.entity.CartItem;
import com.service.order_service.repository.CartRepository;
import com.service.order_service.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    public Cart createCart(Long userId) {
        Cart cart = new Cart();
        cart.setUserId(userId);
        return cartRepository.save(cart);
    }

    public CartItem addItemToCart(Long cartId, Long carId, String addon, Long washPackageId) {
        Cart cart = cartRepository.findById(cartId).orElseThrow(() -> new RuntimeException("Cart not found"));
        CartItem cartItem = new CartItem();
        cartItem.setCart(cart);
        cartItem.setCarId(carId);
        cartItem.setAddon(addon);
        cartItem.setWashPackageId(washPackageId);
        return cartItemRepository.save(cartItem);
    }

    public List<CartItem> getCartItems(Long cartId) {
        Cart cart = cartRepository.findById(cartId).orElseThrow(() -> new RuntimeException("Cart not found"));
        return cart.getItems();
    }
}
