package com.service.order_service.model;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class WashPackage {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String washerPrice;
    private String washerPackage;
    private String location;
}
