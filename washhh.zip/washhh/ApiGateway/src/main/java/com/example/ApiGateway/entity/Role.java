package com.example.ApiGateway.entity;

public enum Role {

	ADMIN,
	USER,
	WASHER
	
	
}
