package com.example.ApiGateway.configuration;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiGatewayConfig {

	@Bean
	public RouteLocator gatewayRoutes(RouteLocatorBuilder builder) {
		return builder.routes()
				.route(p -> p.path("/user/login", "/user/register", "/swagger-ui/**")
						.uri("lb://user-service"))

				.route(p -> p.path("/user/{id}", "/user/getCarByUserId/**", "/user/addcar/**", "/user/{userId}/order")
						.uri("lb://user-service"))

				.route(p -> p.path("/user/addwashPackage/**", "/user/washer/*/accept-order/*")
						.uri("lb://user-service"))

				.route(p -> p.path("/user/getAllCar", "/user/all")
						.uri("lb://user-service"))

				.build();
	}
}
