package com.service.user.client;

import com.service.user.Model.Order;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "orderClient", url = "http://localhost:8084/orders/")public interface OrderClient {

    @PostMapping
    public Order createOrder(@RequestBody Order order);

    @GetMapping
    public List<Order> getAllOrders();

    @GetMapping("/{id}")
    public Order getOrderById(@PathVariable Long id);

    @PutMapping("/update/{id}")
    public Order updateOrder(@PathVariable Long id, @RequestBody Order updatedOrder);

    @DeleteMapping("/delete/{id}")
    public void deleteOrder(@PathVariable Long id);

    @PutMapping("/accept/{orderId}/washer/{washerId}")
    Order acceptOrder(@PathVariable Long orderId, @PathVariable Long washerId);

    @PutMapping("/complete/{orderId}/washer/{washerId}")
    Order completeOrder(@PathVariable Long orderId,@PathVariable Long washerId);
}