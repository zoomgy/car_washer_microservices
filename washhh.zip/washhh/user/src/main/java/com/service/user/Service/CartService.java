package com.service.user.Service;

import com.service.user.Model.Car;
import com.service.user.Model.Cart;
import com.service.user.Model.CartItem;
import com.service.user.Model.WashPackage;
import com.service.user.client.CarClient;
import com.service.user.client.CartClient;
import com.service.user.client.WasherClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service

public class CartService {
    @Autowired
    CartClient cartClient;
    @Autowired
    CarClient carClient;
    @Autowired
    WasherClient washerClient;
    public Cart createCart(Long userId) {
        return cartClient.createCart(userId);

    }

    public CartItem addItemToCart(Long cartId, Long carId, String addons, Long washPackageId,Long userId) {
            Car car1 = carClient.getAllCar().getBody().stream().filter(car -> car.getId().equals(carId)).findFirst().orElse(null);
            if(car1==null || !car1.getUserId().equals(userId)){
                throw new RuntimeException("Invalid Car ID");
            }
            WashPackage washPackage = washerClient.getWashPackageById(washPackageId);
            if(washPackage == null){
                throw new RuntimeException("Invalid Wash Package ID");
            }
            return cartClient.addItemToCart(cartId,carId,addons,washPackageId);
    }

    public List<CartItem> getCartItems(Long cartId) {
        return cartClient.getCartItems(cartId);
    }

    public List<Cart> getCartByUserId(Long userId){
        return cartClient.getCartByUserId(userId);
    }

    public Cart getCartById(Long cartId){
        return cartClient.getCartById(cartId);
    }

    public String deleteCart(Long cartId){
        return cartClient.deleteCart(cartId);
    }

    public boolean deleteCartItem(Long cartId,Long itemId){
        return cartClient.deleteItem(cartId,itemId);
    }
}
