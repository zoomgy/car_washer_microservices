package com.service.user.Service;

import com.service.user.Model.Car;
import com.service.user.Model.Order;
import com.service.user.Model.User;
import com.service.user.Model.WashPackage;
import com.service.user.Repository.UserRepository;
import com.service.user.Security.JwtUtil;
import com.service.user.client.CarClient;
import com.service.user.client.OrderClient;
import com.service.user.client.WasherClient;
import com.service.user.config.OrderPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    private final UserRepository repository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Autowired
    private OrderClient orderClient;

    @Autowired
    private CarClient carClient;

    @Autowired
    private WasherClient washerClient;

    @Autowired
    JwtUtil jwtUtil;

    @Autowired
    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public List<User> getAllUsers() {
        return repository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return repository.findById(id);
    }

    public String registerUser(User user) {
        Optional<User> existingUser = repository.findByUsername(user.getUsername());
        if (existingUser.isPresent()) {
            return "Username already exists!";
        }
        Optional<User> existingEmail = repository.findByEmail(user.getEmail());
        if (existingEmail.isPresent()) {
            return "Email already exists!";
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));
        repository.save(user);
        return "User registered successfully!";
    }

    public String login(String username, String password) {
        Optional<User> existingUser = repository.findByUsername(username);

        if (!existingUser.isPresent()) {
            return "User not found!";
        }

        User user = existingUser.get();
        if (!passwordEncoder.matches(password, user.getPassword())) {
            return "Invalid credentials!";
        }

        return jwtUtil.generateToken(user.getUsername(), user.getRole());
    }

    public ResponseEntity<Car> addNewCar(Long id, Car car) {
        car.setUserId(id);
        return carClient.addNewCar(car);
    }

    public ResponseEntity<List<Car>> getCarByUserId(Long id) {
        return carClient.getCarsByUserID(id);
    }

    public ResponseEntity<List<Car>> getAllCar() {
        return carClient.getAllCar();
    }

    // 🚀 Add a new washer for the user
    public ResponseEntity<WashPackage> addNewWasher( WashPackage washPackage) {

        return ResponseEntity.ok(washerClient.addWashPackage(washPackage));
    }

//    public ResponseEntity<List<WashPackage>> getWasherByUserId(Long id) {
//        List<WashPackage> washPackages = washerClient.getWashPackageByUserId(id);
//        return ResponseEntity.ok(washPackages);
//    }

    public ResponseEntity<List<WashPackage>> getAllWasher(){
        return ResponseEntity.ok(washerClient.getAllWashPackage());
    }

    public Order washerAcceptOrder(Long washerId, Long orderId) {
        return orderClient.acceptOrder(orderId, washerId);
    }

    @Autowired
    private OrderPublisher orderPublisher;

    public Order placeOrder(Long userId, Order order) {
        order.setUserId(userId);
        order.setStatus("PENDING");
        order.setOrderDate(LocalDateTime.now());

        Order createdOrder = orderClient.createOrder(order);

        // Notify washers via RabbitMQ
//        orderPublisher.notifyWashers(createdOrder);

        return createdOrder;
    }

}
