// UserService.java
package com.service.user.Service;

import com.service.user.Exception.*;
import com.service.user.Model.*;
import com.service.user.Entity.User;
import com.service.user.Repository.UserRepository;
import com.service.user.Security.JwtUtil;
import com.service.user.client.*;
import com.service.user.config.OrderPublisher;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

@Service
public class UserService {

    private final UserRepository repository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Autowired private OrderClient orderClient;
    @Autowired private CarClient carClient;
    @Autowired private WasherClient washerClient;
    @Autowired private JwtUtil jwtUtil;
    @Autowired private OrderPublisher orderPublisher;
    @Autowired private CartClient cartClient;

    @Autowired
    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public List<User> getAllUsers() {
        return repository.findAll();
    }

    public User getUserById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User with ID " + id + " not found"));
    }

    public String registerUser(User user) {
        if (repository.findByUsername(user.getUsername()).isPresent()) {
            throw new UsernameAlreadyExistsException("Username already exists!");
        }
        if (repository.findByEmail(user.getEmail()).isPresent()) {
            throw new EmailAlreadyExistsException("Email already exists!");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        repository.save(user);
        return "User registered successfully!";
    }

    public String login(String username, String password) {
        User user = repository.findByUsername(username)
                .orElseThrow(() -> new UserNotFoundException("User not found!"));
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new InvalidCredentialsException("Invalid credentials!");
        }
        return jwtUtil.generateToken(user.getUsername(), user.getRole(),user.getId());
    }

    public User updateUser(Long id, User updatedUser) {
        User user = getUserById(id);
        user.setUsername(updatedUser.getUsername());
        user.setEmail(updatedUser.getEmail());
        return repository.save(user);
    }

    public String changePassword(Long id, String oldPassword, String newPassword) {
        User user = getUserById(id);
        if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
            throw new InvalidCredentialsException("Old password does not match.");
        }
        user.setPassword(passwordEncoder.encode(newPassword));
        repository.save(user);
        return "Password updated successfully.";
    }

    public String deleteCar(Long carId){
        carClient.deleteById(carId);
        return "Car deleted successfully";
    }

    public String deleteMyCar(Long userId,Long carId){
        carClient.deleteMyCar(userId,carId);
        return "Your Car deleted successfully";
    }

    public void deleteUser(Long id) {
        if (!repository.existsById(id)) {
            throw new UserNotFoundException("User not found!");
        }
        repository.deleteById(id);
        carClient.deleteCarsByUserId(id);
    }

    public ResponseEntity<Car> addNewCar(Long id, Car car) {
        if (!repository.existsById(id)) {
            throw new UserNotFoundException("Cannot add car. User with ID " + id + " not found.");
        }
        if(carClient.getCarByLicensePlate(car.getLicensePlate())!=null){
            throw new RuntimeException("Car already added to a User");
        }
        car.setUserId(id);
        return carClient.addNewCar(car);
    }

    @CircuitBreaker(name = "userService", fallbackMethod = "getCarByUserIdFallback")
    public ResponseEntity<List<Car>> getCarByUserId(Long id) {
        if (!repository.existsById(id)) {
            throw new UserNotFoundException("User with ID " + id + " not found.");
        }
        return carClient.getCarsByUserID(id);
    }

    public ResponseEntity<String> getCarByUserIdFallback(Long id, Throwable throwable) {
        return ResponseEntity.status(503).body("Car service is currently unavailable. Please try again later.");
    }

    public ResponseEntity<List<Car>> getAllCar() {
        return carClient.getAllCar();
    }

    public ResponseEntity<WashPackage> addNewWasher(WashPackage washPackage) {
        WashPackage alreadyExist = washerClient.getAllWashPackage().stream().filter(washPackage1 -> washPackage1.getWasherPackage().equals(washPackage.getWasherPackage())).findFirst().orElse(null);
        if(alreadyExist!=null){
            throw new RuntimeException("Wash Package Already Exists");
        }
        return ResponseEntity.ok(washerClient.addWashPackage(washPackage));
    }

    public ResponseEntity<List<WashPackage>> getAllWasher() {
        return ResponseEntity.ok(washerClient.getAllWashPackage());
    }

    public Order washerAcceptOrder(Long washerId, Long orderId) {
        return orderClient.acceptOrder(orderId, washerId);
    }

    public Order washerCompleteOrder(Long washerId, Long orderId) {
        String result = orderClient.completeOrder(orderId, washerId);

        if (!"COMPLETED".equals(result)) {
            throw new RuntimeException(result);
        }
        return orderClient.getOrderById(orderId);
    }

    public Order placeOrder(Long userId, Order order) {
        if (!repository.existsById(userId)) {
            throw new UserNotFoundException("Cannot place order. User with ID " + userId + " not found.");
        }
        Cart cart = cartClient.getCartById(order.getCartId());
        if(cart == null || !Objects.equals(cart.getUserId(), userId)){
            throw new RuntimeException("Invalid Cart");
        }
        Order notCompletedOrders = orderClient.getPendingOrders().stream().filter(order1 -> order1.getUserId().equals(userId) && !order1.getStatus().equals("COMPLETED")).findFirst().orElse(null);
        if(notCompletedOrders!=null){
            throw new RuntimeException("Cannot place order. User with ID " + userId + " has a non completed order with order id "+notCompletedOrders.getId());
        }
        order.setUserId(userId);
        order.setStatus("PENDING");
        order.setOrderDate(LocalDateTime.now());

        Order createdOrder = orderClient.createOrder(order);
        orderPublisher.notifyWashers(createdOrder);

        return createdOrder;
    }

    public Order deleteOrder(Long userId){
        if (!repository.existsById(userId)) {
            throw new UserNotFoundException("Cannot place order. User with ID " + userId + " not found.");
        }
        Order notCompletedOrders = orderClient.getPendingOrders().stream().filter(order1 -> order1.getUserId().equals(userId) && !order1.getStatus().equals("COMPLETED")).findFirst().orElse(null);
        if(notCompletedOrders==null){
            throw new RuntimeException("Cannot delete order. User with ID " + userId + " has a no pending orders");
        }
        orderClient.deleteOrder(notCompletedOrders.getId());
        return notCompletedOrders;
    }

    public List<Order> getOrdersByUserId(Long userId) {
        if (!repository.existsById(userId)) {
            throw new UserNotFoundException("User not found!");
        }
        return orderClient.getOrdersByUserId(userId);
    }

    public List<Order> getPendingOrders(){
        return orderClient.getPendingOrders();
    }
}
