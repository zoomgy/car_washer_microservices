package com.service.user.Model;



import jakarta.persistence.*;


public class Car {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String carName;
    private String model;
    private String licensePlate;
    private Long userId;
    public Car(){

    }
    public Car(String carName, String model, Long id, String licensePlate, Long userId) {
        this.carName = carName;
        this.model = model;
        this.id = id;
        this.licensePlate = licensePlate;
        this.userId = userId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
