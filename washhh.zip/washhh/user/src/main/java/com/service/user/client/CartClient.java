package com.service.user.client;

import com.service.user.Model.Cart;
import com.service.user.Model.CartItem;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "cartClient", url = "http://localhost:8084/carts/")
public interface CartClient {

    @PostMapping("/create")
    public Cart createCart(@RequestParam Long userId);
    @PostMapping("/{cartId}/addItem")
    public CartItem addItemToCart(@PathVariable Long cartId, @RequestParam Long carId, @RequestParam String addons, @RequestParam Long washPackageId);

    @GetMapping("/{cartId}/items")
    public List<CartItem> getCartItems(@PathVariable Long cartId);

}