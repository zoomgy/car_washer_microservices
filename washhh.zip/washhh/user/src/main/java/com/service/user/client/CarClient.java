package com.service.user.client;

import com.service.user.Model.Car;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "exampleClient", url = "http://localhost:8081/")
public interface CarClient {

    @GetMapping("/car/getAllCar")
    public ResponseEntity<List<Car>> getAllCar();

    @PostMapping("/car/addCar")
    public ResponseEntity<Car> addNewCar(@RequestBody Car car);

    @GetMapping("/car/getCarByUserId/{id}")
    public ResponseEntity<List<Car>> getCarsByUserID(@PathVariable Long id);

    @DeleteMapping("/car/delete-by-userid/{userId}")
    public ResponseEntity<List<Car>> deleteCarsByUserId(@PathVariable Long userId);

    @DeleteMapping("/car/delete-by-id/{carId}")
    public ResponseEntity<String> deleteById(@PathVariable Long carId);

    @DeleteMapping("/car/{userId}/delete-my-car/{carId}")
    public ResponseEntity<String> deleteMyCar(@PathVariable Long userId,@PathVariable Long carId);

    @GetMapping("/car/get-car-by-licensePlate/{licensePlate}")
    public Car getCarByLicensePlate(@PathVariable String licensePlate);
}