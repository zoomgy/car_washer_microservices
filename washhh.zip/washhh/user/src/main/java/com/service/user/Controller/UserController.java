package com.service.user.Controller;

import com.service.user.Entity.*;
import com.service.user.Model.*;
import com.service.user.Security.JwtUtil;
import com.service.user.Service.CartService;
import com.service.user.Service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService service;
    private final CartService cartService;
    private JwtUtil jwtUtil;

    @Autowired
    public UserController(UserService service, CartService cartService, JwtUtil jwtUtil) {
        this.service = service;
        this.cartService = cartService;
        this.jwtUtil = jwtUtil;
    }

    // Public Routes
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.registerUser(user));
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody User user) {
        return ResponseEntity.ok(service.login(user.getUsername(), user.getPassword()));
    }

    // Admin Routes
    @GetMapping("/me")
    public String getMyUserId(HttpServletRequest request) {
        return getUserNameFromTokenRequest(request);
    }

    @GetMapping("/get-user-by-id/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getUserById(id));
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(service.getAllUsers());
    }

    @DeleteMapping("/delete-user/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        service.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully.");
    }

    @DeleteMapping("/delete-car-byid/{carId}")
    public ResponseEntity<String> deleteCar(@PathVariable Long carId) {
        service.deleteCar(carId);
        return ResponseEntity.ok("Car deleted successfully");
    }

    @GetMapping("/get-car-by-userid/{id}")
    public ResponseEntity<List<Car>> getCarByUserId(@PathVariable Long id) {
        return service.getCarByUserId(id);
    }

    @GetMapping("/get-all-car")
    public ResponseEntity<List<Car>> getAllCar() {
        return ResponseEntity.ok(service.getAllCar().getBody());
    }

    @PostMapping("/add-wash-package")
    public ResponseEntity<WashPackage> addWasherToUser(@RequestBody WashPackage washPackage) {
        return service.addNewWasher(washPackage);
    }

    @GetMapping("/get-all-wash-package")
    public ResponseEntity<List<WashPackage>> getAllWasher() {
        return service.getAllWasher();
    }

    // User Routes
    @PutMapping("/update-user")
    public ResponseEntity<User> updateUser(@RequestBody User updatedUser, HttpServletRequest request) {
        Long id = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.updateUser(id, updatedUser));
    }

    @PutMapping("/change-password")
    public ResponseEntity<String> changePassword(@RequestParam String oldPassword, @RequestParam String newPassword, HttpServletRequest request) {
        Long id = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.changePassword(id, oldPassword, newPassword));
    }

    @PostMapping("/add-car")
    public ResponseEntity<Car> addCarToUser(@RequestBody Car car, HttpServletRequest request) {
        Long id = getUserIdFromTokenRequest(request);
        return service.addNewCar(id, car);
    }

    @GetMapping("/get-my-car")
    public ResponseEntity<List<Car>> getMyCar(HttpServletRequest request) {
        Long userId = getUserIdFromTokenRequest(request);
        return service.getCarByUserId(userId);
    }

    @DeleteMapping("/delete-my-car/{carId}")
    public ResponseEntity<String> deleteMyCar(@PathVariable Long carId, HttpServletRequest request) {
        Long userId = getUserIdFromTokenRequest(request);
        service.deleteMyCar(userId, carId);
        return ResponseEntity.ok("Your Car deleted successfully");
    }

    @PostMapping("/carts/create")
    public ResponseEntity<Cart> createCart(HttpServletRequest request) {
        Long userId = getUserIdFromTokenRequest(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.createCart(userId));
    }

    @DeleteMapping("/carts/delete-cart/{cartId}")
    public ResponseEntity<String> deleteCart(@PathVariable Long cartId, HttpServletRequest request) {
        Cart cartToBeDeleted = cartService.getCartById(cartId);
        Long userId = getUserIdFromTokenRequest(request);
        if (cartToBeDeleted == null || !cartToBeDeleted.getUserId().equals(userId)) {
            throw new RuntimeException("Invalid Cart ID");
        } else {
            cartService.deleteCart(cartId);
            return ResponseEntity.ok("Cart deleted successfully");
        }
    }

    private Long getUserIdFromTokenRequest(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        String username = jwtUtil.extractUsername(token);
        return jwtUtil.extractUserId(token);
    }

    private String getUserNameFromTokenRequest(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);
        return jwtUtil.extractUsername(token);
    }
}
