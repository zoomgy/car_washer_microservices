// UserController.java
package com.service.user.Controller;

import com.service.user.Entity.*;
import com.service.user.Model.*;
import com.service.user.Security.JwtUtil;
import com.service.user.Service.CartService;
import com.service.user.Service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService service;
    private final CartService cartService;
    private JwtUtil jwtUtil;

    @Autowired
    public UserController(UserService service, CartService cartService,JwtUtil jwtUtil) {
        this.service = service;
        this.cartService = cartService;
        this.jwtUtil = jwtUtil;
    }



    //Public Routes

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.registerUser(user));
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody User user) {
        return ResponseEntity.ok(service.login(user.getUsername(), user.getPassword()));
    }



    //_______________________________________________________________________________________________________________________________________

    //ADMIN Routes


    @GetMapping("/me")
    public String getMyUserId(HttpServletRequest request){
        return getUserNameFromTokenRequest(request);
    }

    @GetMapping("/get-user-by-id/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getUserById(id));
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(service.getAllUsers());
    }

    @DeleteMapping("/delete-user/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        service.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully.");
    }

    @DeleteMapping("/delete-car-byid/{carId}")
    public ResponseEntity<String> deleteCar(@PathVariable Long carId){
        service.deleteCar(carId);
        return ResponseEntity.ok("Car deleted successfully");
    }

    @GetMapping("/get-car-by-userid/{id}")
    public ResponseEntity<List<Car>> getCarByUserId(@PathVariable Long id) {
        return service.getCarByUserId(id);
    }

    @GetMapping("/get-all-car")
    public ResponseEntity<List<Car>> getAllCar() {
        return ResponseEntity.ok(service.getAllCar().getBody());
    }

    @PostMapping("/add-wash-package")
    public ResponseEntity<WashPackage> addWasherToUser(@RequestBody WashPackage washPackage) {
        return service.addNewWasher(washPackage);
    }

    @GetMapping("/get-all-wash-package")
    public ResponseEntity<List<WashPackage>> getAllWasher() {
        return service.getAllWasher();
    }

    //_______________________________________________________________________________________________________________________________________










    //_______________________________________________________________________________________________________________________________________

    // USER Routes

    @PutMapping("/update-user")
    public ResponseEntity<User> updateUser(@RequestBody User updatedUser,HttpServletRequest request) {
        Long id = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.updateUser(id, updatedUser));
    }

    @PutMapping("/change-password")
    public ResponseEntity<String> changePassword(@RequestParam String oldPassword, @RequestParam String newPassword,HttpServletRequest request) {
        Long id = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.changePassword(id, oldPassword, newPassword));
    }

    @PostMapping("/add-car")
    public ResponseEntity<Car> addCarToUser(@RequestBody Car car,HttpServletRequest request) {
        Long id = getUserIdFromTokenRequest(request);
        return service.addNewCar(id, car);
    }

    @GetMapping("/get-my-car")
    public ResponseEntity<List<Car>> getMyCar(HttpServletRequest request){
        Long userId = getUserIdFromTokenRequest(request);
        return service.getCarByUserId(userId);
    }

    @DeleteMapping("/delete-my-car/{carId}")
    public ResponseEntity<String> deleteMyCar(@PathVariable Long carId,HttpServletRequest request){
        Long userId = getUserIdFromTokenRequest(request);
        service.deleteMyCar(userId,carId);
        return ResponseEntity.ok("Your Car deleted successfully");
    }

    @PostMapping("/carts/create")
    public ResponseEntity<Cart> createCart(HttpServletRequest request) {
        Long userId = getUserIdFromTokenRequest(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.createCart(userId));
    }

    @DeleteMapping("/carts/delete-cart/{cartId}")
    public ResponseEntity<String> deleteCart(@PathVariable Long cartId,HttpServletRequest request){
        Cart cartToBeDeleted = cartService.getCartById(cartId);
        Long userId = getUserIdFromTokenRequest(request);
        if(cartToBeDeleted==null || !cartToBeDeleted.getUserId().equals(userId)){
            throw new RuntimeException("Invalid Cart ID");
        }else{
            return new ResponseEntity<>(cartService.deleteCart(cartId),HttpStatus.OK);
        }
    }

    @GetMapping("/carts/get-all-carts")
    public ResponseEntity<List<Cart>> getAllCarts(HttpServletRequest request){
        Long userId = getUserIdFromTokenRequest(request);
        return new ResponseEntity<>(cartService.getCartByUserId(userId),HttpStatus.FOUND);
    }

    @PostMapping("/carts/add-item/{cartId}")
    public ResponseEntity<CartItem> addItemToCart(@PathVariable Long cartId,@RequestBody CartItem cartItem, HttpServletRequest request)
    {
        Long userId = getUserIdFromTokenRequest(request);
        Cart cart = cartService.getCartById(cartId);
        if(cart==null || !Objects.equals(cart.getUserId(), userId)){
            throw new RuntimeException("Invalid Cart Id");
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.addItemToCart(cartId, cartItem.getCarId(), cartItem.getAddons(), cartItem.getWashPackageId(),userId));
    }

    @GetMapping("/carts/get-items/{cartId}")
    public ResponseEntity<List<CartItem>> getCartItems(@PathVariable Long cartId,HttpServletRequest request) {
        Long userId = getUserIdFromTokenRequest(request);
        Cart cart = cartService.getCartById(cartId);
        if(cart==null || !Objects.equals(cart.getUserId(), userId)){
            throw new RuntimeException("Invalid Cart Id");
        }
        return ResponseEntity.ok(cartService.getCartItems(cartId));
    }

    @DeleteMapping("carts/delete-items/{cartId}/{itemId}")
    public ResponseEntity<List<CartItem>> deleteCartItems(@PathVariable Long cartId,@PathVariable Long itemId,HttpServletRequest request) {
        Long userId = getUserIdFromTokenRequest(request);
        Cart cart = cartService.getCartById(cartId);

        if (cart == null) {
            throw new RuntimeException("Invalid Cart Id");
        }

        CartItem cartItem = cart.getItems().stream()
                .filter(item -> item.getId().equals(itemId))
                .findFirst()
                .orElse(null);

        if (!Objects.equals(cart.getUserId(), userId)) {
            throw new RuntimeException("Unauthorized access to this cart");
        }

        if (cartItem == null) {
            throw new RuntimeException("Invalid item Id");
        }
        cartService.deleteCartItem(cartId,itemId);
        return ResponseEntity.ok(cartService.getCartItems(cartId));
    }

    @PostMapping("/place-order")
    public ResponseEntity<Order> placeOrder(@RequestBody Order order,HttpServletRequest request) {
        Long userId = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.placeOrder(userId, order));
    }

    @DeleteMapping("/delete-order")
    public ResponseEntity<Order> deleteOrder(HttpServletRequest request){
        Long userId = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.deleteOrder(userId));
    }

    @GetMapping("/get-order")
    public ResponseEntity<List<Order>> getOrders(HttpServletRequest request){
        Long userId = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.getOrdersByUserId(userId));
    }
    //_______________________________________________________________________________________________________________________________________













    //_______________________________________________________________________________________________________________________________________
    // WASHER ROUTES

    @PutMapping("/washer/accept-order/{orderId}")
    public ResponseEntity<Order> acceptOrder(@PathVariable Long orderId,HttpServletRequest request) {
        Long washerId = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.washerAcceptOrder(washerId, orderId));
    }

    @PutMapping("/washer/complete-order/{orderId}")
    public ResponseEntity<Order> completeOrder(@PathVariable Long orderId,HttpServletRequest request) {
        Long washerId = getUserIdFromTokenRequest(request);
        return ResponseEntity.ok(service.washerCompleteOrder(washerId,orderId));
    }

    @GetMapping("/pending-orders")
    public ResponseEntity<List<Order>> getPendingOrders(){
        return ResponseEntity.ok(service.getPendingOrders());
    }
    //_______________________________________________________________________________________________________________________________________








    // ROLE EXTRACTION

    public String getUserNameFromTokenRequest(HttpServletRequest request){
        String authHeader = request.getHeader("Authorization");
        String jwt = authHeader.substring(7);
        return jwtUtil.extractUsername(jwt);
    }

    public Long getUserIdFromTokenRequest(HttpServletRequest request){
        String authHeader = request.getHeader("Authorization");
        String jwt = authHeader.substring(7);
        return jwtUtil.extractUserId(jwt);
    }
}