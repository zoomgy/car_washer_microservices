// UserController.java
package com.service.user.Controller;

import com.service.user.Entity.*;
import com.service.user.Model.*;
import com.service.user.Service.CartService;
import com.service.user.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService service;
    private final CartService cartService;

    @Autowired
    public UserController(UserService service, CartService cartService) {
        this.service = service;
        this.cartService = cartService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getUserById(id));
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(service.getAllUsers());
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.registerUser(user));
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody User user) {
        return ResponseEntity.ok(service.login(user.getUsername(), user.getPassword()));
    }

    @PutMapping("/update-user/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User updatedUser) {
        return ResponseEntity.ok(service.updateUser(id, updatedUser));
    }

    @PutMapping("/change-password/{id}")
    public ResponseEntity<String> changePassword(@PathVariable Long id, @RequestParam String oldPassword, @RequestParam String newPassword) {
        return ResponseEntity.ok(service.changePassword(id, oldPassword, newPassword));
    }

    @DeleteMapping("/delete-user/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        service.deleteUser(id);
        return ResponseEntity.ok("User deleted successfully.");
    }

    @PostMapping("/add-car/{id}")
    public ResponseEntity<Car> addCarToUser(@PathVariable Long id, @RequestBody Car car) {
        return service.addNewCar(id, car);
    }

    @GetMapping("/get-car-by-userid/{id}")
    public ResponseEntity<List<Car>> getCarByUserId(@PathVariable Long id) {
        return service.getCarByUserId(id);
    }

    @GetMapping("/get-all-car")
    public ResponseEntity<List<Car>> getAllCar() {
        return ResponseEntity.ok(service.getAllCar().getBody());
    }

    @PostMapping("/add-wash-package")
    public ResponseEntity<WashPackage> addWasherToUser(@RequestBody WashPackage washPackage) {
        return service.addNewWasher(washPackage);
    }

    @GetMapping("/get-all-wash-package")
    public ResponseEntity<List<WashPackage>> getAllWasher() {
        return service.getAllWasher();
    }

    @PostMapping("/place-order/{userId}")
    public ResponseEntity<Order> placeOrder(@PathVariable Long userId, @RequestBody Order order) {
        return ResponseEntity.ok(service.placeOrder(userId, order));
    }

    @GetMapping("/orders/{id}")
    public ResponseEntity<List<Order>> getUserOrders(@PathVariable Long id) {
        return ResponseEntity.ok(service.getOrdersByUserId(id));
    }

    @PutMapping("/washer/{washerId}/accept-order/{orderId}")
    public ResponseEntity<Order> acceptOrder(@PathVariable Long washerId, @PathVariable Long orderId) {
        return ResponseEntity.ok(service.washerAcceptOrder(washerId, orderId));
    }

    @PutMapping("/washer/{washerId}/complete-order/{orderId}")
    public ResponseEntity<Order> completeOrder(@PathVariable Long washerId , @PathVariable Long orderId){
        return ResponseEntity.ok(service.washerCompleteOrder(washerId,orderId));
    }

    @PostMapping("/carts/create")
    public ResponseEntity<Cart> createCart(@RequestParam Long userId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.createCart(userId));
    }

    @PostMapping("/carts/{cartId}/addItem")
    public ResponseEntity<CartItem> addItemToCart(
            @PathVariable Long cartId,
            @RequestParam Long carId,
            @RequestParam String addons,
            @RequestParam Long washPackageId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.addItemToCart(cartId, carId, addons, washPackageId));
    }

    @GetMapping("/carts/{cartId}/items")
    public ResponseEntity<List<CartItem>> getCartItems(@PathVariable Long cartId) {
        return ResponseEntity.ok(cartService.getCartItems(cartId));
    }
}