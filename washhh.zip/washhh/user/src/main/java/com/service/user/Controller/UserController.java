package com.service.user.Controller;

import com.service.user.Entity.*;
import com.service.user.Model.*;
import com.service.user.Service.CartService;
import com.service.user.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService service;
    private final CartService cartService;

    @Autowired
    public UserController(UserService service, CartService cartService) {
        this.service = service;
        this.cartService = cartService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getUserById(id));
    }

    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(service.getAllUsers());
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody User user) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.registerUser(user));
    }

    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody User user) {
        return ResponseEntity.ok(service.login(user.getUsername(), user.getPassword()));
    }

    @PostMapping("/addcar/{id}")
    public ResponseEntity<Car> addCarToUser(@PathVariable Long id, @RequestBody Car car) {
        return service.addNewCar(id, car);
    }

    @GetMapping("/getCarByUserId/{id}")
    public ResponseEntity<List<Car>> getCarByUserId(@PathVariable Long id) {
        return service.getCarByUserId(id);
    }

    @GetMapping("/getAllCar")
    public ResponseEntity<List<Car>> getAllCar() {
        return ResponseEntity.ok(service.getAllCar().getBody());
    }

    @PostMapping("/addwashPackage")
    public ResponseEntity<WashPackage> addWasherToUser(@RequestBody WashPackage washPackage) {
        return service.addNewWasher(washPackage);
    }

    @GetMapping("/getAllWashPackage")
    public ResponseEntity<List<WashPackage>> getAllWasher() {
        return service.getAllWasher();
    }

    @PostMapping("/{userId}/order")
    public ResponseEntity<Order> placeOrder(@PathVariable Long userId, @RequestBody Order order) {
        return ResponseEntity.ok(service.placeOrder(userId, order));
    }

    @PutMapping("/washer/{washerId}/accept-order/{orderId}")
    public ResponseEntity<Order> acceptOrder(@PathVariable Long washerId, @PathVariable Long orderId) {
        return ResponseEntity.ok(service.washerAcceptOrder(washerId, orderId));
    }

    @PutMapping("/washer/{washerId}/complete-order/{orderId}")
    public ResponseEntity<Order> completeOrder(@PathVariable Long washerId , @PathVariable Long orderId){
        return ResponseEntity.ok(service.washerCompleteOrder(washerId,orderId));
    }

    // Cart endpoints

    @PostMapping("/carts/create")
    public ResponseEntity<Cart> createCart(@RequestParam Long userId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.createCart(userId));
    }

    @PostMapping("/carts/{cartId}/addItem")
    public ResponseEntity<CartItem> addItemToCart(
            @PathVariable Long cartId,
            @RequestParam Long carId,
            @RequestParam String addons,
            @RequestParam Long washPackageId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(cartService.addItemToCart(cartId, carId, addons, washPackageId));
    }

    @GetMapping("/carts/{cartId}/items")
    public ResponseEntity<List<CartItem>> getCartItems(@PathVariable Long cartId) {
        return ResponseEntity.ok(cartService.getCartItems(cartId));
    }
}
