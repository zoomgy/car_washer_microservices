package com.service.user.Service;

import com.service.user.Model.Cart;
import com.service.user.Model.CartItem;
import com.service.user.client.CartClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class CartServiceTest {

    @Mock
    private CartClient cartClient;

    @InjectMocks
    private CartService cartService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateCart() {
        Long userId = 1L;
        Cart cart = new Cart();
        when(cartClient.createCart(userId)).thenReturn(cart);

        Cart result = cartService.createCart(userId);

        assertNotNull(result);
        verify(cartClient, times(1)).createCart(userId);
    }

    @Test
    public void testAddItemToCart() {
        Long cartId = 1L;
        Long carId = 1L;
        String addons = "addons";
        Long washPackageId = 1L;
        CartItem cartItem = new CartItem();
        when(cartClient.addItemToCart(cartId, carId, addons, washPackageId)).thenReturn(cartItem);

        CartItem result = cartService.addItemToCart(cartId, carId, addons, washPackageId);

        assertNotNull(result);
        verify(cartClient, times(1)).addItemToCart(cartId, carId, addons, washPackageId);
    }

    @Test
    public void testGetCartItems() {
        Long cartId = 1L;
        List<CartItem> cartItems = List.of(new CartItem(), new CartItem());
        when(cartClient.getCartItems(cartId)).thenReturn(cartItems);

        List<CartItem> result = cartService.getCartItems(cartId);

        assertEquals(2, result.size());
        verify(cartClient, times(1)).getCartItems(cartId);
    }
}
