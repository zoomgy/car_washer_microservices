package com.service.user.Controller;

import com.service.user.Entity.*;
import com.service.user.Model.*;
import com.service.user.Security.JwtUtil;
import com.service.user.Service.CartService;
import com.service.user.Service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserControllerTest {

    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userService;

    @Mock
    private CartService cartService;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private HttpServletRequest httpServletRequest;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testRegisterUser() {
        User user = new User();
        user.setUsername("testuser");

        when(userService.registerUser(user)).thenReturn("User registered successfully");

        ResponseEntity<String> response = userController.registerUser(user);

        assertEquals(201, response.getStatusCodeValue());
        assertEquals("User registered successfully", response.getBody());
    }

    @Test
    public void testLoginUser() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("password");

        when(userService.login("testuser", "password")).thenReturn("mocked-jwt-token");

        ResponseEntity<String> response = userController.loginUser(user);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("mocked-jwt-token", response.getBody());
    }

    @Test
    public void testGetMyUserId() {
        String jwtToken = "Bearer mocked.jwt.token";
        String username = "testuser";

        when(httpServletRequest.getHeader("Authorization")).thenReturn(jwtToken);
        when(jwtUtil.extractUsername("mocked.jwt.token")).thenReturn(username);

        String result = userController.getMyUserId(httpServletRequest);
        assertEquals("testuser", result);
    }

    @Test
    public void testGetUserIdFromTokenRequest() {
        String jwtToken = "Bearer mocked.jwt.token";

        when(httpServletRequest.getHeader("Authorization")).thenReturn(jwtToken);
        when(jwtUtil.extractUserId("mocked.jwt.token")).thenReturn(42L);

        Long userId = userController.getUserIdFromTokenRequest(httpServletRequest);
        assertEquals(42L, userId);
    }

    @Test
    public void testGetUserById() {
        User user = new User();
        user.setId(1L);

        when(userService.getUserById(1L)).thenReturn(user);

        ResponseEntity<User> response = userController.getUserById(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1L, response.getBody().getId());
    }

    @Test
    public void testGetAllUsers() {
        User user = new User();
        user.setId(1L);
        when(userService.getAllUsers()).thenReturn(List.of(user));

        ResponseEntity<List<User>> response = userController.getAllUsers();

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
    }

    // You can continue adding similar test cases for each endpoint based on your needs
}
