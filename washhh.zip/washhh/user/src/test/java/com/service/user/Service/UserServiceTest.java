package com.service.user.Service;

import com.service.user.Model.Car;
import com.service.user.Model.Order;
import com.service.user.Model.User;
import com.service.user.Model.WashPackage;
import com.service.user.Repository.UserRepository;
import com.service.user.Security.JwtUtil;
import com.service.user.client.CarClient;
import com.service.user.client.OrderClient;
import com.service.user.client.WasherClient;
import com.service.user.config.OrderPublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class UserServiceTest {


}
