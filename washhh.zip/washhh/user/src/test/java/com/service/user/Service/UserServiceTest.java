package com.service.user.Service;

import com.service.user.Entity.User;
import com.service.user.Exception.*;
import com.service.user.Model.*;
import com.service.user.Repository.UserRepository;
import com.service.user.Security.JwtUtil;
import com.service.user.client.*;
import com.service.user.config.OrderPublisher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @InjectMocks
    private UserService userService;

    @Mock private UserRepository userRepository;
    @Mock private CarClient carClient;
    @Mock private WasherClient washerClient;
    @Mock private OrderClient orderClient;
    @Mock private JwtUtil jwtUtil;
    @Mock private OrderPublisher orderPublisher;
    @Mock private CartClient cartClient;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterUser_Success() {
        User user = new User();
        user.setUsername("testuser");
        user.setEmail("test@example.com");
        user.setPassword("password");

        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.empty());
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.empty());

        String result = userService.registerUser(user);

        assertEquals("User registered successfully!", result);
        verify(userRepository).save(any(User.class));
    }

    @Test
    void testRegisterUser_UsernameExists() {
        User user = new User();
        user.setUsername("testuser");
        when(userRepository.findByUsername("testuser")).thenReturn(Optional.of(new User()));

        assertThrows(UsernameAlreadyExistsException.class, () -> userService.registerUser(user));
    }

    @Test
    void testGetUserById_UserExists() {
        User user = new User();
        user.setId(1L);
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        User foundUser = userService.getUserById(1L);
        assertEquals(1L, foundUser.getId());
    }

    @Test
    void testGetUserById_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, () -> userService.getUserById(1L));
    }

    @Test
    void testChangePassword_Success() {
        User user = new User();
        user.setId(1L);
        user.setPassword(passwordEncoder.encode("oldpass"));

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        String result = userService.changePassword(1L, "oldpass", "newpass");

        assertEquals("Password updated successfully.", result);
        verify(userRepository).save(any(User.class));
    }


    @Test
    void testDeleteUser_NotFound() {
        when(userRepository.existsById(1L)).thenReturn(false);
        assertThrows(UserNotFoundException.class, () -> userService.deleteUser(1L));
    }


    @Test
    public void testLogin_UserNotFound() {
        when(userRepository.findByUsername("nonexistent")).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> {
            userService.login("nonexistent", "password");
        });
    }

    @Test
    public void testLogin_InvalidPassword() {
        User mockUser = new User();
        mockUser.setId(1L);
        mockUser.setUsername("test");
        mockUser.setPassword(passwordEncoder.encode("correct-password"));
        mockUser.setRole("USER");

        when(userRepository.findByUsername("test")).thenReturn(Optional.of(mockUser));

        assertThrows(InvalidCredentialsException.class, () -> {
            userService.login("test", "wrong-password");
        });
    }

}
