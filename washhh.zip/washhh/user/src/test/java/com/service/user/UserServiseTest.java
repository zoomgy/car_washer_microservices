package com.service.user;


import com.service.user.Model.User;
import com.service.user.Repository.UserRepository;
import com.service.user.Security.JwtUtil;
import com.service.user.Service.UserService;
import com.service.user.client.CarClient;
import com.service.user.client.OrderClient;
import com.service.user.client.WasherClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private OrderClient orderClient;

    @Mock
    private CarClient carClient;

    @Mock
    private WasherClient washerClient;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private UserService userService;

    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        userService = new UserService(userRepository);
        user = new User();
        user.setId(1L);
        user.setUsername("testUser");
        user.setEmail("test@example.com");
        user.setPassword("password");
    }

    @Test
    void testRegisterUser() {
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.empty());
        when(userRepository.findByEmail(user.getEmail())).thenReturn(Optional.empty());

        String result = userService.registerUser(user);

        assertThat(result).isEqualTo("User registered successfully!");
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testLogin() {
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.of(user));
        when(jwtUtil.generateToken(user.getUsername(), user.getRole())).thenReturn("token");

        String result = userService.login(user.getUsername(), user.getPassword());

        assertThat(result).isEqualTo("token");
    }

    // Add more test methods for other functionalities
}
