package com.service.admin.Controller;

import com.service.admin.Model.Car;
import com.service.admin.Service.CarService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/car")
public class CarController {

    private final CarService service;

    public CarController(CarService service) {
        this.service = service;
    }

    @GetMapping("/getAllCar")
    public ResponseEntity<List<Car>> getAllCar(){
        return ResponseEntity.ok(service.getAll());
    }

    // Endpoint to add a new car
    @PostMapping("/addCar")
    public ResponseEntity<Car> addNewCar(@RequestBody Car car) {
        Car savedCar = service.addNewCar(car);
        return new ResponseEntity<>(savedCar, HttpStatus.CREATED);
    }

    @GetMapping("/getCar/{id}")
    public ResponseEntity<Car> getCarById(@PathVariable Long id){
        return new ResponseEntity<>(service.getCarById(id),HttpStatus.OK);
    }

    @GetMapping("/getCarByUserId/{id}")
    public ResponseEntity<List<Car>> getCarsByUserID(@PathVariable Long id){
        return new ResponseEntity<>(service.getCarByUserId(id),HttpStatus.OK);
    }

    // Endpoint to delete a car by ID
    @DeleteMapping("/deleteCar/{id}")
    public ResponseEntity<String> deleteCar(@PathVariable Long id) {
        Car isDeleted = service.deleteACar(id);
        if (isDeleted!=null) {
            return new ResponseEntity<>("Car successfully deleted.", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Car not found.", HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete-by-userid/{userId}")
    public ResponseEntity<List<Car>> deleteCarsByUserId(@PathVariable Long userId){
        List<Car> deletedCars = service.deleteCarsByUserId(userId);
        return new ResponseEntity<>(deletedCars,HttpStatus.OK);
    }

    @DeleteMapping("/delete-by-id/{carId}")
    public ResponseEntity<String> deleteById(@PathVariable Long carId){
        Car deletedCar = service.deleteACar(carId);
        if(deletedCar==null){
            return new ResponseEntity<>("Car Not Deleted",HttpStatus.BAD_GATEWAY);
        }
        return new ResponseEntity<>("Car Deleted Successfully",HttpStatus.OK);
    }

    @DeleteMapping("/{userId}/delete-my-car/{carId}")
    public ResponseEntity<String> deleteMyCar(@PathVariable Long userId,@PathVariable Long carId){
        Car deletedCar = service.deleteMyCar(userId,carId);
        if(deletedCar==null){
            return new ResponseEntity<>("Car Not Deleted",HttpStatus.BAD_GATEWAY);
        }
        return new ResponseEntity<>("Car Deleted Successfully",HttpStatus.OK);
    }


    // Additional endpoints could be added here as needed for other functionalities.
}