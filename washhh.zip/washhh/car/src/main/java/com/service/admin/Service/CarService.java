package com.service.admin.Service;


import com.service.admin.Model.Car;
import com.service.admin.Repository.CarRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CarService {

    @Autowired
    public CarRepository carRepository;

    public Car addNewCar(Car car){
        return carRepository.save(car);
    }

    public Car getCarById(Long id){
        Optional<Car> car = carRepository.findById(id);
        return car.orElse(null);
    }

    public List<Car> getAll(){
        return carRepository.findAll();
    }

    public List<Car> getCarByUserId(Long userId){
        return carRepository.findAll().stream().filter(car -> car.getUserId().equals(userId)).toList();
    }

    public Car deleteACar(Long id) {
        try {
            Car carForDelete = null;
            if(carRepository.findById(id).isPresent())carForDelete = carRepository.findById(id).get();
            if(carForDelete!=null){
                carRepository.delete(carForDelete);
                return carForDelete;
            }
            else{
                throw new EntityNotFoundException("Car Not found");// Deletes the retrieved car entry
            }
        } catch (EntityNotFoundException e) {
            return null;
        }
    }

    public List<Car> deleteCarsByUserId(Long userId){
        try {
            List<Car> carForDelete = carRepository.findByUserId(userId);
            for(Car car : carForDelete){
                carRepository.delete(car);// Deletes the retrieved car entry
            }
            return carForDelete;
        } catch (EntityNotFoundException e) {
            return new ArrayList<>();
        }
    }

    public Car deleteMyCar(Long userId,Long carId){
        try{
            Car carToBeDeleted = null;
            Optional<Car> carFromDatabase = carRepository.findById(carId);
            if(carFromDatabase.isPresent())carToBeDeleted = carFromDatabase.get();
            if(carToBeDeleted != null){
                if(!carToBeDeleted.getUserId().equals(userId))return null;
                carRepository.delete(carToBeDeleted);
            }
            return carToBeDeleted;
        }catch (EntityNotFoundException e){
            return null;
        }
    }

    public Car getCarByLicensePlate(String licensePlate) {
        return carRepository.findAll().stream()
                .filter(car -> car.getLicensePlate().equals(licensePlate))
                .findFirst()
                .orElse(null);
    }
}
