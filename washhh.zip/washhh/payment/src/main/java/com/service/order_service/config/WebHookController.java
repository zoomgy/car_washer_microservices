package com.service.order_service.config;

import com.service.order_service.service.PaymentService;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.model.Event;
import com.stripe.model.checkout.Session;
import com.stripe.net.Webhook;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;


@RestController
@RequestMapping("/api/webhook")
public class WebHookController {

    @Value("${stripe.webhook.secret}")
    private String endpointSecret;

    private final PaymentService paymentService;


    public WebHookController(PaymentService paymentService){
        this.paymentService = paymentService;
    }

    @PostMapping
    public ResponseEntity<String> handleStripeWebhook(HttpServletRequest request){
        System.out.println("Received Stripe Signature Header: " + request.getHeader("Stripe-Signature"));
        String payload;
        try {
            payload = StreamUtils.copyToString(request.getInputStream(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        String sigHeader = request.getHeader("Stripe-Signature");
        System.out.println("Received payload: " + payload);
        System.out.println("Received signature: " + sigHeader);
        Event event;
        try{
            event = Webhook.constructEvent(payload,sigHeader,endpointSecret,300);
        } catch (SignatureVerificationException e) {
            throw new RuntimeException(e);
        }
        if("checkout.session.completed".equals(event.getType())){
            Session session = (Session) event.getDataObjectDeserializer().getObject().orElse(null);
            if(session !=null){
                String orderId = session.getMetadata().get("orderId");
                paymentService.markAsPaid(Long.parseLong(orderId));
            }
        }else if("checkout.session.expired".equals(event.getType()) || "payment_intent.canceled".equals(event.getType())){
            Session session = (Session) event.getDataObjectDeserializer().getObject().orElse(null);
            if(session !=null){
                String orderId = session.getMetadata().get("orderId");
                paymentService.markAsCancelled(Long.parseLong(orderId));
            }
        }
        return ResponseEntity.ok("");
    }
}
