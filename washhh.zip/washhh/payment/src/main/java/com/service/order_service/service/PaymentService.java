package com.service.order_service.service;

import com.service.order_service.entity.Payment;
import com.service.order_service.repository.PaymentRepository;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.model.checkout.Session;
import com.stripe.param.PaymentIntentCreateParams;
import com.stripe.param.checkout.SessionCreateParams;
import org.apache.http.protocol.HTTP;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    public String createNewPayment(Long orderId,Long amount) {
        List<Payment> pendingPaymentListWithOrderId = paymentRepository.findAll().stream().filter(payment -> payment.getOrderId().equals(orderId) && payment.getStatus().equals("PENDING")).toList();
        if(!pendingPaymentListWithOrderId.isEmpty()){
            return "PAYMENT WITH "+pendingPaymentListWithOrderId.getFirst().getId() + " FOR ORDER NUMBER "+orderId+" IS STILL PENDING PLEASE CANCEL OR COMPLETE THAT PAYMENT TO INITIATE NEW PAYMENT FOR THE ORDER";
        }
        List<Payment> completedPaymentListWithOrderId = paymentRepository.findAll().stream().filter(payment -> payment.getOrderId().equals(orderId) && payment.getStatus().equals("COMPLETED")).toList();
        if(!completedPaymentListWithOrderId.isEmpty()){
            return "PAYMENT WITH "+completedPaymentListWithOrderId.getFirst().getId() + " FOR ORDER NUMBER "+orderId+" IS ALREADY COMPLETED SUCCESSFULLY INITIATE NEW ORDER";
        }
        Payment newPayment  = new Payment();
        newPayment.setOrderId(orderId);
        newPayment.setAmount(amount);

        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl("http://localhost:8082/user/success")
                .setCancelUrl("http://localhost:8082/user/fail")
                .putMetadata("orderId",orderId+"")
                .addLineItem(
                        SessionCreateParams.LineItem.builder()
                                .setQuantity(1L)
                                .setPriceData(
                                        SessionCreateParams.LineItem.PriceData.builder()
                                                .setCurrency("INR")
                                                .setUnitAmount(amount)
                                                .setProductData(
                                                        SessionCreateParams.LineItem.PriceData.ProductData.builder().setName("CAR WASH").build()
                                                )
                                                .build()
                                )
                                .build()
                ).build();
        try {
            Session session = Session.create(params);
            newPayment.setSessionId(session.getId());
            paymentRepository.save(newPayment);
            return newPayment.getId() + ",PAYMENT CREATED SUCCESSFULLY WITH PAYMENT URL " + session.getUrl();
        } catch (StripeException e) {
            return "PAYMENT NOT CREATED";
        }
    }

    public void markAsPaid(Long orderId){
        Payment findById = paymentRepository.findByOrderId(orderId).stream().filter(payment -> payment.getStatus().equals("PENDING")).toList().getFirst();
        findById.setPaymentCompleteDate(LocalDateTime.now());
        findById.setStatus("SUCCESS");
        paymentRepository.save(findById);
    }

    public void markAsCancelled(Long orderId){
        Payment findById = paymentRepository.findByOrderId(orderId).stream().filter(payment -> payment.getStatus().equals("PENDING")).toList().getFirst();
        findById.setPaymentCompleteDate(LocalDateTime.now());
        findById.setStatus("CANCELED");
        paymentRepository.save(findById);
    }


    public List<Payment> getPaymentWithOrderId(Long orderId){
        return paymentRepository.findAll().stream().filter(payment -> payment.getOrderId().equals(orderId)).toList();
    }


    public String getPaymentStatus(Long paymentId){
        Optional<Payment> payment = paymentRepository.findById(paymentId);
        if(payment.isPresent()){
            return payment.get().getStatus();
        }else{
            return "INVALID";
        }
    }
}
