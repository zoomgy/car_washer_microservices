package com.service.order_service.controller;

import com.service.order_service.entity.Payment;
import com.service.order_service.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/new/{orderId}/{amount}")
    public String createNewPayment(@PathVariable Long orderId,@PathVariable Long amount){
        return paymentService.createNewPayment(orderId,amount);
    }

    @GetMapping("/status/{paymentId}")
    public String getPaymentStatus(@PathVariable Long paymentId){
        return paymentService.getPaymentStatus(paymentId);
    }


    @GetMapping("/get-all-payment/{orderId}")
    public List<Payment> getAllPayment(@PathVariable Long orderId){
        return paymentService.getPaymentWithOrderId(orderId);
    }
}
