package com.service.order_service.repository;


import com.service.order_service.entity.Payment;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByStatus(String status);
    List<Payment> findByOrderId(Long orderId);

}
